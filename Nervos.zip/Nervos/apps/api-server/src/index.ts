// API server entry point
console.log("AI Interview Backend starting...");
