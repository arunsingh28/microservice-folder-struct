// Database package entry point
export const placeholder = "database";
