// Auth package entry point
export const placeholder = "auth";
