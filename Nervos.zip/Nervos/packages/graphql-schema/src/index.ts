// GraphQL schema package entry point
export const placeholder = "graphql-schema";
