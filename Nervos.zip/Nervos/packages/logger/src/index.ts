// Logger package entry point
export const placeholder = "logger";
