// Shared package entry point
export const placeholder = "shared";
